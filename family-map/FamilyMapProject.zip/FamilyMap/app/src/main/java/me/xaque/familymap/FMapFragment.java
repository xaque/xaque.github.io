package me.xaque.familymap;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import java.util.Arrays;
import java.util.HashSet;

import me.xaque.familymap.shared.model.Event;
import me.xaque.familymap.shared.model.Person;


public class FMapFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {
    private GoogleMap googleMap;
    private MapView mapView;
    private TextView markerTitle;
    private TextView markerDescription;
    private ImageView markerIcon;
    private String personId;
    private HashSet<Event> events;
    private HashSet<Person> persons;
    private String startingEvent;

    public FMapFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, final Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_fmap, container, false);

        //Get the view objects for the selected event marker description box.
        markerTitle = (TextView) view.findViewById(R.id.markerDescriptionTitle);
        markerDescription = (TextView) view.findViewById(R.id.markerDescriptionContent);
        markerIcon = (ImageView) view.findViewById(R.id.markerGenderIcon);
        //When user clicks on event box, it creates a new activity for the person to whom the event belongs
        view.findViewById(R.id.markerDescription).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (personId == null){
                    return;
                }
                Intent intent = new Intent(getActivity(), PersonActivity.class);
                intent.putExtra(getString(R.string.person_id_key), personId);
                startActivity(intent);
            }
        });
        //Set up Google Maps
        mapView = (MapView) view.findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.onResume();
        MapsInitializer.initialize(getActivity().getApplicationContext());
        mapView.getMapAsync(this);
        return view;
    }

    //Clears everything from the map and calls the method to reload the current data
    public void resetMap(){
        if (googleMap != null){
            googleMap.clear();
        }

        personId = null;
        loadMapData();
    }

    @Override
    public void onMapReady(GoogleMap map) {
        //Sets global map settings and then calls method to load data into map
        googleMap = map;
        googleMap.getUiSettings().setMapToolbarEnabled(false);
        googleMap.setOnMarkerClickListener(this);
        loadMapData();
    }

    //Loads person event data into the Google map.
    public void loadMapData(){
        persons = new HashSet<>();
        events = new HashSet<>();
        Gson gson = new Gson();
        SharedPreferences prefs = getActivity().getSharedPreferences(getString(R.string.app_path), Context.MODE_PRIVATE);
        String personsJson = prefs.getString(getString(R.string.user_person_data_key), "");
        String eventsJson = prefs.getString(getString(R.string.user_event_data_key), "");
        persons = new HashSet<>(Arrays.asList( gson.fromJson(personsJson, Person[].class) ));
        events = new HashSet<>(Arrays.asList( gson.fromJson(eventsJson, Event[].class) ));
        loadMapMarkers();
    }

    //Creates markers on the Google map for each event
    public void loadMapMarkers(){
        for (Event e : events){
            MarkerOptions m = new MarkerOptions()
                    .position(new LatLng(e.getLatitude(), e.getLongitude()))
                    .draggable(false)
                    .icon(BitmapDescriptorFactory.defaultMarker(getMarkerColor(e.getEventType())))
                    .title(e.getId());
            googleMap.addMarker(m);
        }

        if (startingEvent != null){
            moveCamera(startingEvent);
            setMarkerTextBox(startingEvent);
        }
    }


    //Used to set an event for the Google map camera to start on.
    public void setStartingEvent(String eventId){
        startingEvent = eventId;
    }

    //Finds person by id
    public Person findPerson(String personId){
        for (Person p : persons){
            if (p.getId().equals(personId)){
                return p;
            }
        }
        return null;
    }

    //Finds event by id
    public Event findEvent(String eventId){
        for (Event e : events){
            if (e.getId().equals(eventId)){
                return e;
            }
        }
        return null;
    }

    //Selects marker color based on event type
    public float getMarkerColor(String eventType){
        switch (eventType){
            case ("birth"):
                return getActivity().getPreferences(Context.MODE_PRIVATE).getFloat(getString(R.string.marker_color_birth_key), BitmapDescriptorFactory.HUE_AZURE);
            case ("baptism"):
                return getActivity().getPreferences(Context.MODE_PRIVATE).getFloat(getString(R.string.marker_color_baptism_key), BitmapDescriptorFactory.HUE_GREEN);
            case ("marriage"):
                return getActivity().getPreferences(Context.MODE_PRIVATE).getFloat(getString(R.string.marker_color_marriage_key), BitmapDescriptorFactory.HUE_RED);
            case ("death"):
                return getActivity().getPreferences(Context.MODE_PRIVATE).getFloat(getString(R.string.marker_color_death_key), BitmapDescriptorFactory.HUE_VIOLET);
        }
        return BitmapDescriptorFactory.HUE_YELLOW;
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        //Hides the info window that shows be default since we are using a custom info window
        marker.hideInfoWindow();
        //Sends event id to put the data for that event in the info box
        setMarkerTextBox(marker.getTitle());
        return true;
    }

    //Fills the selected event info box with data for the given event id
    private void setMarkerTextBox(String eventId){
        Event e = findEvent(eventId);
        Person p = findPerson(e.getPerson());
        personId = p.getId();
        markerTitle.setText(p.getFirstName() + " " + p.getLastName());
        markerDescription.setText(e.getEventType() + ": " + e.getCity() + ", " + e.getCountry() + " (" + e.getYear() +")");
        markerIcon.setVisibility(View.VISIBLE);
        markerIcon.setImageResource(R.drawable.icon_male);
        if (p.getGender().equals("f")){
            markerIcon.setImageResource(R.drawable.icon_female);
        }
    }

    //Moves the camera and zooms on an event marker
    public void moveCamera(String eventId){
        Event e = findEvent(eventId);
        LatLng position = new LatLng(e.getLatitude(), e.getLongitude());
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, 4), 1000, null);
    }

}
