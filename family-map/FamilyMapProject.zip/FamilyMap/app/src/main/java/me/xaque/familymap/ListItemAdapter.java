package me.xaque.familymap;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class ListItemAdapter extends BaseAdapter {
    private Context context;
    String[] titles;
    String[] subtitles;
    Drawable[] icons;
    View[] rightSideViews;
    View.OnClickListener[] clickListeners;

    public ListItemAdapter(Context context, String[] titles, String[] subtitles, Drawable[] icons, View[] rightSideViews, View.OnClickListener[] clickListeners){
        this.context = context;
        this.titles = titles;
        this.subtitles = subtitles;
        this.icons = icons;
        this.rightSideViews = rightSideViews;
        this.clickListeners = clickListeners;
    }

    @Override
    public int getCount() {
        return titles.length;
    }

    @Override
    public Object getItem(int position) {
        return titles[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null){
            view = inflater.inflate(R.layout.subtitled_list_item, null);
        }
        //Set the main text for the list item
        ((TextView)view.findViewById(R.id.subtitled_list_item_main_text)).setText(titles[position]);
        //Set the subtitle for the list item
        ((TextView)view.findViewById(R.id.subtitled_list_item_subtitle)).setText(subtitles[position]);
        //Set the icon for the list item
        if (icons[position] != null){
            ((ImageView)view.findViewById(R.id.sli_imageView)).setImageDrawable(icons[position]);
        }
        //Set a view to appear on the right side of the list item
        if (rightSideViews[position] != null){
            ((LinearLayout)view.findViewById(R.id.sli_rightSideView)).addView(rightSideViews[position]);
        }
        //Sets a click listener on the list item view
        if (clickListeners[position] != null){
            view.setOnClickListener(clickListeners[position]);
        }
        return view;
    }
}
