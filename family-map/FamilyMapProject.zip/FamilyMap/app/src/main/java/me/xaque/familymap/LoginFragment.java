package me.xaque.familymap;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.concurrent.ExecutionException;

import me.xaque.familymap.shared.FMSProxy;
import me.xaque.familymap.shared.result.LoginResult;
import me.xaque.familymap.shared.result.RegisterResult;


public class LoginFragment extends Fragment {
    private static EditText hostField;
    private static EditText portField;
    private static EditText userNameField;
    private static EditText passwordField;
    private static EditText firstNameField;
    private static EditText lastNameField;
    private static EditText emailField;
    private static RadioGroup genderField;
    private static Button signInButton;
    private static Button registerButton;
    private static final int DEFAULT_PORT = 8080;

    private static TextWatcher buttonValidation = new TextWatcher(){
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {        }

        @Override
        public void afterTextChanged(Editable s) {
            enableSignIn();
            enableRegister();
        }
    };

    //Enables the sign in button when appropriate entries are filled
    private static void enableSignIn(){
        boolean setEnable = false;
        if (!hostField.getText().toString().equals("") &&
                !portField.getText().toString().equals("") &&
                !userNameField.getText().toString().equals("") &&
                !passwordField.getText().toString().equals("")) {

            setEnable = true;
        }
        signInButton.setEnabled(setEnable);
    }

    //Enables the register button when appropriate entries are filled
    private static void enableRegister(){
        boolean setEnable = false;
        if (!hostField.getText().toString().equals("") &&
                !portField.getText().toString().equals("") &&
                !userNameField.getText().toString().equals("") &&
                !passwordField.getText().toString().equals("") &&
                !firstNameField.getText().toString().equals("") &&
                !lastNameField.getText().toString().equals("") &&
                !emailField.getText().toString().equals("") &&
                genderField.getCheckedRadioButtonId() != -1) {

            setEnable = true;
        }
        registerButton.setEnabled(setEnable);
    }

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        //Gets all the edit text fields from the login/register form
        hostField = (EditText) view.findViewById(R.id.editServerHost);
        portField = (EditText) view.findViewById(R.id.editServerPort);
        userNameField = (EditText) view.findViewById(R.id.editUserName);
        passwordField = (EditText) view.findViewById(R.id.editPassword);
        firstNameField = (EditText) view.findViewById(R.id.editFirstName);
        lastNameField = (EditText) view.findViewById(R.id.editLastName);
        emailField = (EditText) view.findViewById(R.id.editEmail);
        genderField = (RadioGroup) view.findViewById(R.id.editGender);
        //Adds listeners to form items to update button enable status
        hostField.addTextChangedListener(buttonValidation);
        portField.addTextChangedListener(buttonValidation);
        userNameField.addTextChangedListener(buttonValidation);
        passwordField.addTextChangedListener(buttonValidation);
        firstNameField.addTextChangedListener(buttonValidation);
        lastNameField.addTextChangedListener(buttonValidation);
        emailField.addTextChangedListener(buttonValidation);
        genderField.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                enableRegister();
                enableSignIn();
            }
        });

        signInButton = (Button) view.findViewById(R.id.buttonSignIn);
        registerButton = (Button) view.findViewById(R.id.buttonRegister);

        signInButton.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        signIn(v);
                    }
                }
        );

        registerButton.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        register(v);
                    }
                }
        );

        return view;
    }

    //
    private void signIn(View view){
        int port = DEFAULT_PORT;
        try{
            port = Integer.parseInt(portField.getText().toString());
        }catch (Exception e){}
        //communicates with FMS server to make a login request
        FMSProxy.PROXY.setServer(hostField.getText().toString(), port);
        LoginNetworkTask lnt = new LoginNetworkTask();
        lnt.execute("signIn", userNameField.getText().toString(), passwordField.getText().toString());
        try {
            String authtoken = lnt.get();
            ((MainActivity)getActivity()).dataSync(authtoken);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    private void register(View view){
        int port = DEFAULT_PORT;
        try{
            port = Integer.parseInt(portField.getText().toString());
        }catch (Exception e){}
        //communicates with FMS server to make register request
        FMSProxy.PROXY.setServer(hostField.getText().toString(), port);
        RadioButton gender = (RadioButton) genderField.findViewById(genderField.getCheckedRadioButtonId());
        LoginNetworkTask lnt = new LoginNetworkTask();
        lnt.execute("register", userNameField.getText().toString(), passwordField.getText().toString(), emailField.getText().toString(), firstNameField.getText().toString(), lastNameField.getText().toString(), gender.getText().toString().toLowerCase().substring(0,1));
        try {
            String authtoken = lnt.get();
            ((MainActivity)getActivity()).dataSync(authtoken);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    //Makes login or register request on background thread
    private class LoginNetworkTask extends AsyncTask<String, String, String> {
        private String authtoken;
        @Override
        protected String doInBackground(String... params) {
            switch (params[0]) {
                case ("signIn"):
                    LoginResult lr = FMSProxy.PROXY.login(params[1], params[2]);
                    if (lr == null){
                        publishProgress("signIn", null);
                    }
                    else{
                        authtoken = lr.getAuthToken();
                        publishProgress("signIn", lr.getAuthToken());
                    }
                    break;
                case ("register"):
                    RegisterResult rr = FMSProxy.PROXY.register(params[1], params[2], params[3], params[4], params[5], params[6]);
                    if (rr == null){
                        publishProgress("register", null);
                    }
                    else{
                        authtoken = rr.getAuthToken();
                        publishProgress("register", rr.getAuthToken());
                    }
                    break;
            }
            return authtoken;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            if (values[1] == null){
                Toast.makeText(getActivity().getApplicationContext(), values[0] + " failed.", Toast.LENGTH_SHORT).show();
            }
            else{
                ((MainActivity)getActivity()).setFragmentMap();
            }
        }

    }

}
