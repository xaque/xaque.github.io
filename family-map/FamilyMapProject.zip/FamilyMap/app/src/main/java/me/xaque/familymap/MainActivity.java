package me.xaque.familymap;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.Arrays;
import java.util.HashSet;

import me.xaque.familymap.shared.FMSProxy;
import me.xaque.familymap.shared.model.Event;
import me.xaque.familymap.shared.model.Person;

public class MainActivity extends AppCompatActivity {
    private HashSet<Person> persons;
    private HashSet<Event> events;
    private boolean isLoggedIn;
    private String authtoken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Create default toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(myToolbar);
        isLoggedIn = false;
        //Create login fragment in main activity
        setFragmentLogin();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        if (isLoggedIn){
            getMenuInflater().inflate(R.menu.menu_main, menu);
        }
        else{
            getMenuInflater().inflate(R.menu.menu_login, menu);
        }
        //
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //Starts new activity for respective menu item that is clicked.
        switch (item.getItemId()) {
            case R.id.action_settings:
                startActivity(new Intent(this, SettingsActivity.class));
                return true;

            case R.id.action_filter:
                startActivity(new Intent(this, FilterActivity.class));
                return true;

            case R.id.action_search:
                startActivity(new Intent(this, SearchActivity.class));
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    //Creates login fragment on the main activity
    public void setFragmentLogin(){
        isLoggedIn = false;
        Fragment newFragment = new LoginFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_container, newFragment);

        transaction.commit();
    }

    //Creates map fragment on the main activity.
    public void setFragmentMap(){
        isLoggedIn = true;
        //Creates toolbar menu items once main activity changes to map fragment
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar_main);
        invalidateOptionsMenu();
        setSupportActionBar(myToolbar);
        Fragment newFragment = new FMapFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        transaction.replace(R.id.fragment_container, newFragment);

        transaction.commit();
    }

    //Downloads Person and Event data from the server for the user with the given authtoken
    public boolean dataSync(String authtoken){
        this.authtoken = authtoken;
        DataSyncTask dst = new DataSyncTask();
        dst.execute(authtoken);
        return true;
    }

    //Network task to sync Person and Event data on background thread
    private class DataSyncTask extends AsyncTask<String, Object[], String> {
        @Override
        protected String doInBackground(String... params) {
            publishProgress(FMSProxy.PROXY.getPersonsForUser(params[0]), FMSProxy.PROXY.getEventsForUser(params[0]));
            return null;
        }

        @Override
        protected void onProgressUpdate(Object[]... values) {
            super.onProgressUpdate(values);
            if (values[0] == null || values[1] == null) {
                Toast.makeText(getApplicationContext(), "Failed to sync data from server.", Toast.LENGTH_SHORT).show();
                return;
            }
            //Stores the person and event data locally on the device
            persons = new HashSet<>(Arrays.asList((Person[])values[0]));
            events = new HashSet<>(Arrays.asList((Event[])values[1]));
            SharedPreferences.Editor editor = getSharedPreferences(getString(R.string.app_path), Context.MODE_PRIVATE).edit();
            Gson gson = new Gson();
            String personsJson = gson.toJson(persons.toArray(new Person[persons.size()]));
            String eventsJson = gson.toJson(events.toArray(new Event[events.size()]));
            editor.putString(getString(R.string.user_person_data_key), personsJson);
            editor.putString(getString(R.string.user_event_data_key), eventsJson);
            editor.commit();
        }

    }

}
