package me.xaque.familymap;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.Arrays;
import java.util.HashSet;

import me.xaque.familymap.shared.model.Event;
import me.xaque.familymap.shared.model.Person;

public class PersonActivity extends AppCompatActivity {
    private HashSet<Person> persons;
    private HashSet<Event> events;
    private Person thisPerson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person);
        //Create default toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Loads person and event data from the device cache
        persons = new HashSet<>();
        events = new HashSet<>();
        Gson gson = new Gson();
        SharedPreferences prefs = getSharedPreferences(getString(R.string.app_path), Context.MODE_PRIVATE);
        String personsJson = prefs.getString(getString(R.string.user_person_data_key), "");
        String eventsJson = prefs.getString(getString(R.string.user_event_data_key), "");
        persons = new HashSet<>(Arrays.asList( gson.fromJson(personsJson, Person[].class) ));
        events = new HashSet<>(Arrays.asList( gson.fromJson(eventsJson, Event[].class) ));

        //Loads the starting person for the activity from the intent
        thisPerson = findPerson(getIntent().getStringExtra(getString(R.string.person_id_key)));

        //Sets the UI elements to match selected person info
        ((TextView)findViewById(R.id.personFirstName)).setText(thisPerson.getFirstName());
        ((TextView)findViewById(R.id.personLastName)).setText(thisPerson.getLastName());
        if (thisPerson.getGender().equals("f")){
            ((TextView)findViewById(R.id.personGender)).setText("Female");
        }else{
            ((TextView)findViewById(R.id.personGender)).setText("Male");
        }

        //Creates list of events belonging to the person
        LinearLayout eventList = (LinearLayout) findViewById(R.id.personEventsContainer);

        for (Event e : events){
            if (e.getPerson().equals(thisPerson.getId())){
                TextView child = (TextView) getLayoutInflater().inflate(R.layout.person_event_list_item, null);
                final String eventId = e.getId();
                child.setText(e.getEventType() + ": " + e.getCity() + ", " + e.getCountry() + " (" + e.getYear() + ")");
                //Event descriptions will open a new Activity when clicked
                child.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        createNewMapActivity(eventId);
                    }
                });
                eventList.addView(child);
            }
        }

        //Creates list of family members
        LinearLayout familyList = (LinearLayout) findViewById(R.id.personFamilyContainer);

        //Person descriptions will open a new activity when clicked
        if (thisPerson.getFather() != null){
            Person father = findPerson(thisPerson.getFather());
            familyList.addView(makePersonListItem(father, "Father"));
        }
        if (thisPerson.getMother()!= null){
            Person mother = findPerson(thisPerson.getMother());
            familyList.addView(makePersonListItem(mother, "Mother"));
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_with_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.action_home:
                Intent intent = new Intent(this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    //Creates a list item view for a person
    private View makePersonListItem(Person p, String relationship){
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        final String personId = p.getId();
        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNewPersonActivity(personId);
            }
        });
        TextView personRel = ((TextView) getLayoutInflater().inflate(R.layout.person_list_item, null));
        TextView personName = ((TextView) getLayoutInflater().inflate(R.layout.person_list_item, null));
        personName.setText(p.getFirstName() + " " + p.getLastName());
        personRel.setText(relationship + ":");
        layout.addView(personRel);
        layout.addView(personName);
        return layout;
    }


    private void createNewPersonActivity(String personId){
        Intent intent = new Intent(this, PersonActivity.class);
        intent.putExtra(getString(R.string.person_id_key), personId);
        startActivity(intent);
    }

    private void createNewMapActivity(String eventId){
        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra(getString(R.string.event_id_key), eventId);
        startActivity(intent);
    }

    //Finds person based on id
    private Person findPerson(String personId){
        for (Person p : persons){
            if (p.getId().equals(personId)){
                return p;
            }
        }
        return null;
    }

}
