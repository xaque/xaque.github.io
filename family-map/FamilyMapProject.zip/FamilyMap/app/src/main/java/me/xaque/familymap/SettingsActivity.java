package me.xaque.familymap;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        //Creates default toolbar
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Creates a list view of different settings options
        ListView settingsList = (ListView) findViewById(R.id.settings_list);

        String[] titles = {"Life Story Lines", "" +
                "Family Tree Lines",
                "Spouse Lines",
                "Map Type",
                "Re-sync Data",
                "Logout"};
        String[] subtitles = {"Show Life History Lines",
                "Show Familt Tree Lines",
                "Show Spouse Lines",
                "Background Display on Map",
                "From FamilyMap Service",
                "Returns to Login Screen"};
        View.OnClickListener[] clickListeners = {new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //show life
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //show fam
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //show spouse
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //back gr
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {/*
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(getString(R.string.resync_server), true);
                startActivity(intent);*/
            }
        }, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //logout
            }
        }};

        //Adapter creates list items for the UI based on the arrays of data for each part of the list item.
        settingsList.setAdapter(new ListItemAdapter(this, titles, subtitles, new Drawable[6], new View[6], clickListeners));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

}
