package me.xaque.familymap.shared;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import me.xaque.familymap.shared.model.Event;
import me.xaque.familymap.shared.model.Person;
import me.xaque.familymap.shared.model.User;
import me.xaque.familymap.shared.request.LoadRequest;
import me.xaque.familymap.shared.request.LoginRequest;
import me.xaque.familymap.shared.request.RegisterRequest;
import me.xaque.familymap.shared.request.Request;
import me.xaque.familymap.shared.result.ClearResult;
import me.xaque.familymap.shared.result.EventResult;
import me.xaque.familymap.shared.result.EventsResult;
import me.xaque.familymap.shared.result.FillResult;
import me.xaque.familymap.shared.result.LoadResult;
import me.xaque.familymap.shared.result.LoginResult;
import me.xaque.familymap.shared.result.PeopleResult;
import me.xaque.familymap.shared.result.PersonResult;
import me.xaque.familymap.shared.result.RegisterResult;

/**
 * <b>The FMSProxy makes HTTP requests to the FMS at the client's command</b><br>
 * <pre>
 * The FMSProxy is implemented as a singleton. The client can make requests through the public methods on this object.
 * The FMSProxy takes the Request object,
 * encodes it to JSON,
 * sends it to the FMS,
 * gets the server response,
 * decodes that from JSON into a Response object,
 * and returns that to the client.
 * </pre>
 */
public class FMSProxy {
    /**
     * The singleton instance of the FMS proxy
     */
    public static FMSProxy PROXY = new FMSProxy();
    private static Gson gson = new Gson();

    private String HOSTNAME = "localhost";
    private int SERVER_PORT_NUMBER = 8080;
    private static final String AUTH_KEY = "Authorization";

    private static final String CLEAR_CONTEXT = "/clear";
    private static final String EVENT_CONTEXT = "/event";
    private static final String FILL_CONTEXT = "/fill";
    private static final String LOAD_CONTEXT = "/load";
    private static final String LOGIN_CONTEXT = "/user/login";
    private static final String PERSON_CONTEXT = "/person";
    private static final String REGISTER_CONTEXT = "/user/register";


    private FMSProxy(){}

    public void setServer(String host, int port){
        HOSTNAME = host;
        SERVER_PORT_NUMBER = port;
    }

    /**
     * Sends a request to clear all data from the FMS database
     * @return Whether the clear was successful
     */
    public boolean clearData(){
        HttpURLConnection c = openConnection(CLEAR_CONTEXT, "", false);
        if (c == null){
            return false;
        }
        ClearResult result = getResult(c, ClearResult.class);
        if (result.getMessage().startsWith("Success")){
            return true;
        }
        return false;
    }

    /**
     * Sends a request to get an Event from the server
     * @param eventId The Id of the Event to get
     * @param authToken The authentication token for the current user
     * @return The Event object retrieved from the server
     */
    public Event getEvent(String eventId, String authToken){
        HttpURLConnection c = openConnection(EVENT_CONTEXT + "/" + eventId, authToken, false);
        if (c == null){
            return null;
        }
        EventResult result = getResult(c, EventResult.class);
        return result.extractEvent();
    }

    /**
     * Send a request to the server to get all Events associated with the current user
     * @param authToken The authentication token for the current user
     * @return The array of all Events associated with the user
     */
    public Event[] getEventsForUser(String authToken){
        HttpURLConnection c = openConnection(EVENT_CONTEXT, authToken, false);
        if (c == null){
            return null;
        }
        EventsResult result = getResult(c, EventsResult.class);
        return result.getEvents();
    }

    /**
     * Sends a request to fill the FMS database with randomly generated data for a given user
     * @param username The username for whom to generate family history data
     * @param generations The number of generations of data to generate
     * @return Whether the fill was successful
     */
    public boolean fillData(String username, int generations){
        HttpURLConnection c = openConnection(FILL_CONTEXT + "/" + username + "/" + generations, "", false);
        if (c == null){
            return false;
        }
        FillResult result = getResult(c, FillResult.class);
        if (result.getMessage().startsWith("Success")){
            return true;
        }
        return false;
    }

    /**
     * Sends a request to load the given data into the FMS database and clear everything else
     * @param users The array of Users to add to the database
     * @param persons The array of Persons to add to the database
     * @param events The array of Events to add to the database
     * @return Whether the load was successful
     */
    public boolean loadData(User[] users, Person[] persons, Event[] events){
        HttpURLConnection c = openConnection(LOAD_CONTEXT, "", true);
        if (c == null){
            return false;
        }
        sendRequest(c, new LoadRequest(users, persons, events));
        LoadResult result = getResult(c, LoadResult.class);
        if (result.getMessage().startsWith("Success")){
            return true;
        }
        return false;
    }

    /**
     * Sends a request to login to the server
     * @param username The username of the user to log in
     * @param password The password of the user to log in
     * @return The authentication token for the login session
     */
    public LoginResult login(String username, String password){
        HttpURLConnection c = openConnection(LOGIN_CONTEXT, "", true);
        if (c == null){
            return null;
        }
        sendRequest(c, new LoginRequest(username, password));
        LoginResult result = getResult(c, LoginResult.class);
        return result;
    }

    /**
     * Sends a request to get a Person object from the server
     * @param personId The Id of the person to get
     * @param authToken The authentication token for the logged in user
     * @return The Person retrieved from the server
     */
    public Person getPerson(String personId, String authToken){
        HttpURLConnection c = openConnection(PERSON_CONTEXT + "/" + personId, authToken, false);
        if (c == null){
            return null;
        }
        PersonResult result = getResult(c, PersonResult.class);
        return result.extractPerson();
    }

    /**
     * Send a request to the FMS to get all Person objects associated with the current user
     * @param authToken The authentication token for the current user
     * @return The array of all Persons associated with the user
     */
    public Person[] getPersonsForUser(String authToken){
        HttpURLConnection c = openConnection(PERSON_CONTEXT, authToken, false);
        if (c == null){
            return null;
        }
        PeopleResult result = getResult(c, PeopleResult.class);
        return result.getPeople();
    }

    /**
     * Send a request to the FMS to register a new user
     * @param username The username for the new user
     * @param password The password for the new user
     * @param email The email address of the new user
     * @param firstName The first name of the new user
     * @param lastName The last name of the new user
     * @param gender The gender of the new user; True for male, false for female
     * @return The auth token for the current login session after registration
     */
    public RegisterResult register(String username, String password, String email, String firstName, String lastName, String gender){
        HttpURLConnection c = openConnection(REGISTER_CONTEXT, "", true);
        if (c == null){
            return null;
        }
        sendRequest(c, new RegisterRequest(username, password, email, firstName, lastName, gender));
        RegisterResult result = getResult(c, RegisterResult.class);
        return result;
    }

    /**
     * Opens an HttpUrlConnection to be able to send and receive data from the FMS
     * @param context The URL context to make the HTTP connection on
     * @param authToken The authorization token for the connection
     * @param sendingObject Whether the connection will have a request body
     * @return The HTTP connection created with the given parameters
     */
    private HttpURLConnection openConnection(String context, String authToken, boolean sendingObject){
        try {
            URL url = new URL("http://" + HOSTNAME + ":" + SERVER_PORT_NUMBER + context);
            HttpURLConnection result = (HttpURLConnection)url.openConnection();
            result.setRequestMethod("POST");
            result.setDoOutput(sendingObject);
            result.setRequestProperty(AUTH_KEY, authToken);
            result.connect();
            return result;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Couldnt make HTTP connection on http://" + HOSTNAME + ":" + SERVER_PORT_NUMBER + context);
        return null;
    }

    /**
     * Sends a Request object on the given HTTP connection
     * @param connection The HTTP connection to send the Request on
     * @param r The request object being sent to the server
     */
    private void sendRequest(HttpURLConnection connection, Request r){
        try {
            OutputStreamWriter osw = new OutputStreamWriter(connection.getOutputStream());
            gson.toJson(r, osw);
            osw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates a Result object from the HTTP response
     * @param connection The connection on which to receive data
     * @return The Result object created from the HTTP response
     */
    private <T> T getResult(HttpURLConnection connection, Class<T> resultType){
        T result = null;
        try {
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                if(connection.getContentLength() == -1) {
                    InputStreamReader isr = new InputStreamReader(connection.getInputStream());
                    result = gson.fromJson(isr, resultType);
                    isr.close();
                }
            }
            else {
                throw new Exception("http code " + connection.getResponseCode());
            }
        } catch (JsonSyntaxException | JsonIOException | IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

}
