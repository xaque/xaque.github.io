package me.xaque.familymap.shared.model;

import java.util.UUID;

/**
 * This class is the Java object representation of a AuthToken database table entry.
 */
public class AuthToken {
    private String token;
    private String username;

    /**
     * AuthToken constructor; generates random token from java.util.UUID
     */
    public AuthToken(String username){
        this.token = UUID.randomUUID().toString();
        this.username = username;
    }

    /**
     * Getter method for the string AuthToken
     * @return The random token for this AuthToken object
     */
    public String getAuthToken(){
        return token;
    }

    /**
     * The getter for username
     * @return The username associated with this auth token
     */
    public String getUsername(){
        return username;
    }
}
