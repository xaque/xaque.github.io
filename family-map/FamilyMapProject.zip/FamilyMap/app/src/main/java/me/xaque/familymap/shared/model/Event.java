package me.xaque.familymap.shared.model;

import java.util.UUID;

/**
 * This class is the Java object representation of an Event database table entry.
 */
public class Event {
    private String eventID;
    private String descendant;
    private String personID;
    private double latitude;
    private double longitude;
    private String country;
    private String city;
    private String eventType;
    private int year;

    /**
     * The constructor for the Event object
     * @param descendant The user to which this event's person belongs
     * @param person The person to which this event belongs
     * @param latitude The latitude of the event
     * @param longitude The longitude of the event
     * @param country The country where the event took place
     * @param city The city where the event took place
     * @param eventType The type of event
     * @param year The year which the event took place
     */
    public Event(String descendant, String person, double latitude, double longitude, String country, String city, String eventType, int year){
        this.eventID= UUID.randomUUID().toString();
        this.descendant = descendant;
        this.personID = person;
        this.latitude = latitude;
        this.longitude = longitude;
        this.country = country;
        this.city = city;
        this.eventType = eventType;
        this.year = year;
    }

    /**
     * The constructor for an Event object with a predetermined Id
     * @param eventId The id already defined for the event
     * @param descendant The user to which this event's person belongs
     * @param person The person to which this event belongs
     * @param latitude The latitude of the event
     * @param longitude The longitude of the event
     * @param country The country where the event took place
     * @param city The city where the event took place
     * @param eventType The type of event
     * @param year The year which the event took place
     */
    public Event(String eventId, String descendant, String person, double latitude, double longitude, String country, String city, String eventType, int year){
        this.eventID = eventId;
        this.descendant = descendant;
        this.personID = person;
        this.latitude = latitude;
        this.longitude = longitude;
        this.country = country;
        this.city = city;
        this.eventType = eventType;
        this.year = year;
    }

    /**
     * The getter for ID
     * @return The ID of this event
     */
    public String getId() {
        return eventID;
    }

    /**
     * The getter for descendant
     * @return The user to which this event belongs
     */
    public String getDescendant() {
        return descendant;
    }

    /**
     * The getter for person
     * @return The person to which this event happened
     */
    public String getPerson() {
        return personID;
    }

    /**
     * The getter for latitude
     * @return The latitude for this event
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     * The getter for longitude
     * @return The longitude for this event
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     * The getter for country
     * @return The country of this event
     */
    public String getCountry() {
        return country;
    }

    /**
     * The getter for city
     * @return The city of this event
     */
    public String getCity() {
        return city;
    }

    /**
     * The getter for eventType
     * @return The type of event
     */
    public String getEventType() {
        return eventType;
    }

    /**
     * The getter for year
     * @return The year of this event
     */
    public int getYear() {
        return year;
    }
}
