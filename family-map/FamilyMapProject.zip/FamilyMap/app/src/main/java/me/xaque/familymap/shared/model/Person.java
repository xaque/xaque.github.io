package me.xaque.familymap.shared.model;

import java.util.UUID;

/**
 * This class is the Java object representation of a Person database table entry.
 */
public class Person {
    private String personID;
    private String descendant;
    private String firstName;
    private String lastName;
    private String gender;
    private String father;
    private String mother;
    private String spouse;

    /**
     * The constructor for Person<br>
     * father, mother, and spouse can be null
     * @param descendant The user to which this person belongs
     * @param firstname The first name of the person
     * @param lastname The last name of the person
     * @param gender The gender of the person: true for male, false for female
     * @param father The Person object for the father of this person
     * @param mother The Person object for the mother of this person
     * @param spouse The Person object for the spouse of this person
     */
    public Person(String descendant, String firstname, String lastname, String gender, String father, String mother, String spouse){
        this.personID = UUID.randomUUID().toString();
        this.descendant = descendant;
        this.firstName = firstname;
        this.lastName = lastname;
        this.gender = gender;
        this.father = father;
        this.mother = mother;
        this.spouse = spouse;
    }

    /**
     * The constructor for Person with predetermined Id<br>
     * father, mother, and spouse can be null
     * @param descendant The user to which this person belongs
     * @param firstname The first name of the person
     * @param lastname The last name of the person
     * @param gender The gender of the person: true for male, false for female
     * @param father The Person object for the father of this person
     * @param mother The Person object for the mother of this person
     * @param spouse The Person object for the spouse of this person
     */
    public Person(String personId, String descendant, String firstname, String lastname, String gender, String father, String mother, String spouse){
        this.personID = personId;
        this.descendant = descendant;
        this.firstName = firstname;
        this.lastName = lastname;
        this.gender = gender;
        this.father = father;
        this.mother = mother;
        this.spouse = spouse;
    }

    /**
     * Set the first name of the Person
     * @param firstName The new first name
     */
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    /**
     * Set the last name of the Person
     * @param lastName The new last name
     */
    public void setLastName(String lastName){
        this.lastName = lastName;
    }

    /**
     * Set the father of the Person
     * @param father The id of the father
     */
    public void setFather(String father){
        this.father = father;
    }

    /**
     * Set the mother of the Person
     * @param mother The id of the mother
     */
    public void setMother(String mother){
        this.mother = mother;
    }

    /**
     * Set the spouse of the Person
     * @param spouse The id of the spouse
     */
    public void setSpouse(String spouse){
        this.spouse = spouse;
    }

    /**
     * The getter for the ID
     * @return The ID of this person
     */
    public String getId() {
        return personID;
    }

    /**
     * The getter for descendant
     * @return The user to which this person belongs
     */
    public String getDescendant() {
        return descendant;
    }

    /**
     * The getter for firstname
     * @return The first name of this person
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * The getter for lastname
     * @return The last name of this person
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * The getter for gender
     * @return The gender of this person: true for male, false for female
     */
    public String getGender() {
        return gender;
    }

    /**
     * The getter for father
     * @return The Person object for the father of this person
     */
    public String getFather() {
        return father;
    }

    /**
     * The getter for mother
     * @return The Person object for the mother of this person
     */
    public String getMother() {
        return mother;
    }

    /**
     * The getter for spouse
     * @return The Person object for the spouse of this person
     */
    public String getSpouse() {
        return spouse;
    }
}
