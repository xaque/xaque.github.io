package me.xaque.familymap.shared.model;

/**
 * This class is the Java object representation of a User database table entry.
 */
public class User {
    private String userName;
    private String password;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;
    private String personID;

    /**
     * The constructor for User
     * @param username The username for the new user
     * @param password  The password for the new user
     * @param email The email address for the new user
     * @param firstname The first name of the new user
     * @param lastname The last name of the new user
     * @param gender The gender of the new user: true for male, false for female
     * @param personID The unique Person ID assigned to this user’s generated Person object
     */
    public User(String username, String password, String email, String firstname, String lastname, String gender, String personID){
        this.userName = username;
        this.password = password;
        this.email = email;
        this.firstName = firstname;
        this.lastName = lastname;
        this.gender = gender;
        this.personID = personID;
    }

    /**
     * Set the person ID for this user
     * @param personID The id for the person representing this user
     */
    public void setPersonID(String personID){
        this.personID = personID;
    }

    /**
     * The getter for username
     * @return The username of the user
     */
    public String getUsername() {
        return userName;
    }

    /**
     * The getter for password
     * @return The password of the user
     */
    public String getPassword() {
        return password;
    }

    /**
     * The getter for email
     * @return The email of the user
     */
    public String getEmail() {
        return email;
    }

    /**
     * The getter for firstname
     * @return The first name of the user
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * The getter for lastname
     * @return The last name of the user
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * The getter for gender
     * @return The gender of the user: true for male, false for female
     */
    public String getGender() {
        return gender;
    }

    /**
     * The getter for the personID
     * @return The person ID associated with this user
     */
    public String getPersonID() {
        return personID;
    }

}
