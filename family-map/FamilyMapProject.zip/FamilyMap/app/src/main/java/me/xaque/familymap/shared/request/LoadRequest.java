package me.xaque.familymap.shared.request;

import me.xaque.familymap.shared.model.Event;
import me.xaque.familymap.shared.model.Person;
import me.xaque.familymap.shared.model.User;

public class LoadRequest implements Request{
    private User[] users;
    private Person[] persons;
    private Event[] events;

    /**
     * The constructor for LoadRequest
     * @param users The array of Users to load into the database
     * @param persons The array of Persons to load into the database
     * @param events The array of Events to load into the database
     */
    public LoadRequest(User[] users, Person[] persons, Event[] events){
        this.users = users;
        this.persons = persons;
        this.events = events;
    }

    /**
     * The getter for users
     * @return The array of Users for this load request
     */
    public User[] getUsers() {
        return users;
    }

    /**
     * The getter for persons
     * @return The array of Persons for this load request
     */
    public Person[] getPersons() {
        return persons;
    }

    /**
     * The getter for events
     * @return The array of Events for this load request
     */
    public Event[] getEvents() {
        return events;
    }
}
