package me.xaque.familymap.shared.request;

public class LoginRequest implements Request{
    private String userName;
    private String password;

    /**
     * The constructor for LoginRequest
     * @param userName The userName to login as
     * @param password The password for the user
     */
    public LoginRequest(String userName, String password){
        this.userName = userName;
        this.password = password;
    }

    /**
     * The getter for username
     * @return The userName of the requested login
     */
    public String getUsername() {
        return userName;
    }

    /**
     * The getter for password
     * @return The password of the requested login
     */
    public String getPassword() {
        return password;
    }
}
