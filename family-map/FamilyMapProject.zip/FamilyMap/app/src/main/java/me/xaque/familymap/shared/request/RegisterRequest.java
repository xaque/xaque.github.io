package me.xaque.familymap.shared.request;

public class RegisterRequest implements Request{
    private String userName;
    private String password;
    private String email;
    private String firstName;
    private String lastName;
    private String gender;

    /**
     * The constructor for RegisterRequest
     * @param userName The requested username
     * @param password The password for new user
     * @param email The email for new user
     * @param firstName The first name for new user
     * @param lastName The last name for new user
     * @param gender The gender of new user: true for male, false for female
     */
    public RegisterRequest(String userName, String password, String email, String firstName, String lastName, String gender){
        this.userName = userName;
        this.password = password;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
    }

    /**
     * The getter for username
     * @return The username of the requested new user
     */
    public String getUsername() {
        return userName;
    }

    /**
     * The getter for password
     * @return The password of the requested new user
     */
    public String getPassword() {
        return password;
    }

    /**
     * The getter for email
     * @return The email of the requested new user
     */
    public String getEmail() {
        return email;
    }

    /**
     * The getter for firstname
     * @return The first name of the requested new user
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * The getter for lastname
     * @return The last name of the requested new user
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * The getter for gender
     * @return The gender of the requested new user: true for male, false for female
     */
    public String getGender() {
        return gender;
    }
}
