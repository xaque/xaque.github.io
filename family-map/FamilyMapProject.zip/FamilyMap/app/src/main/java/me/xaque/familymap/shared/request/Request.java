package me.xaque.familymap.shared.request;

/**
 * All objects sent from client to FMS are sent as objects implementing this interface.<br>
 * This interface simply represents the request body of an HTTP request before being converted to JSON
 */
public interface Request {
}
