package me.xaque.familymap.shared.result;

import me.xaque.familymap.shared.model.Event;

public class EventResult implements Result{
    private String descendant;
    private String eventId;
    private String personId;
    private double latitude;
    private double longitude;
    private String country;
    private String city;
    private String eventType;
    private int year;
    private String message;

    /**
     * The constructor for success EventResult
     * @param e The event to return info for
     */
    public EventResult(Event e){
        this.descendant = e.getDescendant();
        this.eventId = e.getId();
        this.latitude = e.getLatitude();
        this.longitude = e.getLongitude();
        this.country = e.getCountry();
        this.city = e.getCity();
        this.eventType = e.getEventType();
        this.year = e.getYear();
        this.personId = e.getPerson();
    }

    /**
     * The constructor for fail EventResult
     * @param message The error message
     */
    public EventResult(String message){
        this.message = message;
    }

    /**
     * Generate an Event object from the EventResult data
     * @return The newly created Event object
     */
    public Event extractEvent(){
        if (eventId == null){
            return null;
        }
        return new Event(eventId, descendant, personId, latitude, longitude, country, city, eventType, year);
    }

    /**
     * The getter for descendant
     * @return The username of the descendant
     */
    public String getDescendant() {
        return descendant;
    }

    /**
     * The getter for eventId
     * @return The id of the event
     */
    public String getEventId() {
        return eventId;
    }

    /**
     * The getter for latitude
     * @return The latitude of the event
     */
    public double getLatitude() {
        return latitude;
    }

    /**
     * The getter for longitude
     * @return The longitude of the event
     */
    public double getLongitude() {
        return longitude;
    }

    /**
     * The getter for country
     * @return The country of the event
     */
    public String getCountry() {
        return country;
    }

    /**
     * The getter for city
     * @return The city of the event
     */
    public String getCity() {
        return city;
    }

    /**
     * The getter for eventType
     * @return The type of event
     */
    public String getEventType() {
        return eventType;
    }

    /**
     * The getter for year
     * @return The year of the event
     */
    public int getYear() {
        return year;
    }

    /**
     * The getter for message
     * @return The error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Success of the event request
     * @return True if the event is found and return, false if not
     */
    public boolean success(){
        return message == null;
    }

}
