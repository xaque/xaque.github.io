package me.xaque.familymap.shared.result;

import me.xaque.familymap.shared.model.Event;

public class EventsResult implements Result{
    private Event[] events;
    private String message;
    /**
     * The constructor for success EventsResult
     * @param events The array of all Events for the current user
     */
    public EventsResult(Event[] events){
        this.events = events;
    }

    /**
     * The constructor for fail EventsResult
     * @param message The error message
     */
    public EventsResult(String message){
        this.message = message;
    }

    /**
     * The getter for events
     * @return The array of events for the current user
     */
    public Event[] getEvents() {
        return events;
    }

    /**
     * The getter for message
     * @return The error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Successful Events request
     * @return True if events request was successful, false if not
     */
    public boolean success(){
        return message == null;
    }
}
