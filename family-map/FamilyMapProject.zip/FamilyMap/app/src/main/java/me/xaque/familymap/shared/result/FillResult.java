package me.xaque.familymap.shared.result;

public class FillResult implements Result{
    private String message;

    /**
     * The constructor for ClearResult
     * @param message The success or error message of the ClearRequest
     */
    public FillResult(String message){
        this.message = message;
    }

    /**
     * The getter for message
     * @return The success or error message of the ClearResult
     */
    public String getMessage(){
        return message;
    }
}
