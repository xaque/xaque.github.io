package me.xaque.familymap.shared.result;

public class LoginResult implements Result{
    private String authToken;
    private String username;
    private String pid;
    private String message;

    /**
     * The constructor for success RegisterResult
     * @param authToken The authToken for the logged in user
     * @param username The username for the logged in user
     * @param personId The personId for the logged in user
     */
    public LoginResult(String authToken, String username, String personId){
        this.authToken = authToken;
        this.username = username;
        this.pid = personId;
    }

    /**
     * The constructor for fail LoginResult
     * @param message The error message
     */
    public LoginResult(String message){
        this.message = message;
    }

    /**
     * The getter for authToken
     * @return The authentication token for the logged in user
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     * The getter for username
     * @return The username for the logged in user
     */
    public String getUsername() {
        return username;
    }

    /**
     * The getter for personId
     * @return The personId of the logged in user
     */
    public String getPid() {
        return pid;
    }

    /**
     * The getter for message
     * @return The error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Successful login
     * @return True if user logged in, false if not
     */
    public boolean success() {
        return message == null;
    }

}
