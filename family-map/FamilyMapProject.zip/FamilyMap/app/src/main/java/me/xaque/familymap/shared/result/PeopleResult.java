package me.xaque.familymap.shared.result;

import me.xaque.familymap.shared.model.Person;

public class PeopleResult implements Result{
    private Person[] people;
    private String message;

    /**
     * The constructor for success PeopleResult
     * @param people The array of all Persons for the current user
     */
    public PeopleResult(Person[] people){
        this.people = people;
    }

    /**
     * The constructor for fail PeopleResult
     * @param message The error message
     */
    public PeopleResult(String message){
        this.message = message;
    }

    /**
     * The getter for people
     * @return The array of all Persons related to the current user
     */
    public Person[] getPeople() {
        return people;
    }

    /**
     * The getter for message
     * @return The error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Successful People request
     * @return True if people request was successful, false if not
     */
    public boolean success(){
        return message == null;
    }

}
