package me.xaque.familymap.shared.result;

import me.xaque.familymap.shared.model.Person;

public class PersonResult implements Result{
    private String descendant;
    private String personId;
    private String firstname;
    private String lastname;
    private String gender;
    private String father;
    private String mother;
    private String spouse;
    private String message;

    /**
     * The constructor for success PersonResult
     * @param p The person whose details to return
     */
    public PersonResult(Person p){
        this.descendant = p.getDescendant();
        this.personId = p.getId();
        this.firstname = p.getFirstName();
        this.lastname = p.getLastName();
        this.gender = p.getGender();
        this.father = p.getFather();
        this.mother = p.getMother();
        this.spouse = p.getSpouse();
    }

    /**
     * Generate a Person object from the PersonResult data
     * @return The newly created Person object
     */
    public Person extractPerson(){
        if (personId == null){
            return null;
        }
        return new Person(personId, descendant, firstname, lastname, gender, father, mother, spouse);
    }

    /**
     * The constructor for fail PersonResult
     * @param message The error message
     */
    public PersonResult(String message){
        this.message = message;
    }

    /**
     * The getter for descendant
     * @return The username for the descendant
     */
    public String getDescendant() {
        return descendant;
    }

    /**
     * The getter for personId
     * @return The personId of the PersonResult
     */
    public String getPersonId() {
        return personId;
    }

    /**
     * The getter for firstname
     * @return The first name of the PersonResult
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * The getter for lastname
     * @return The last name of the PersonResult
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * The getter for gender
     * @return The gender of the PersonResult: true if male, false if female
     */
    public String getGender() {
        return gender;
    }

    /**
     * The getter for father
     * @return The id of the father
     */
    public String getFather() {
        return father;
    }

    /**
     * The getter for mother
     * @return The id of the mother
     */
    public String getMother() {
        return mother;
    }

    /**
     * The getter for spouse
     * @return The id of the spouse
     */
    public String getSpouse() {
        return spouse;
    }

    /**
     * The getter for message
     * @return The error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Successful person request
     * @return True if person was found and returned, false if not
     */
    public boolean success(){
        return message == null;
    }

}
