package me.xaque.familymap.shared.result;

public class RegisterResult implements Result{
    private String authToken;
    private String username;
    private String pid;
    private String message;

    /**
     * The constructor for success RegisterResult
     * @param authToken The authToken for the new user
     * @param username The username for the created user
     * @param personId The personId for the created user
     */
    public RegisterResult(String authToken, String username, String personId){
        this.authToken = authToken;
        this.username = username;
        this.pid = personId;
    }

    /**
     * The constructor for fail RegisterResult
     * @param message The error message
     */
    public RegisterResult(String message){
        this.message = message;
    }

    /**
     * The getter for authToken
     * @return The authentication token for the new user
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     * The getter for username
     * @return The username for the new user
     */
    public String getUsername() {
        return username;
    }

    /**
     * The getter for personId
     * @return The personId of the new user
     */
    public String getPid() {
        return pid;
    }

    /**
     * The getter for message
     * @return The error message
     */
    public String getMessage() {
        return message;
    }

    /**
     * Successful registration
     * @return True if user was registered, false if not
     */
    public boolean success() {
        return message == null;
    }
}
