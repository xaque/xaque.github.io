package me.xaque.familymap.shared.result;

/**
 * All objects sent from FMS to client are sent as objects implementing this interface.<br>
 * This interface simply represents the response body of an HTTP response before being converted to JSON.
 */
public interface Result {
}
